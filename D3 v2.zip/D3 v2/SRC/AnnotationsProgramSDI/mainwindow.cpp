#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QPixmap>
#include <QMessageBox>
#include <QDir>
#include <dirent.h>
#include <string>
#include <QVector>
#include <QDebug>
#include <QLinkedList>
#include <QMutableLinkedListIterator>

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    scene = new QGraphicsScene(this);
    //QPixmap m("C:\\Users\\Joshua Mc\\Documents\\AnnotationsProgramSDI\\images\\things.jpg");
    //scene->setBackgroundBrush(m.scaled(100,100,Qt::IgnoreAspectRatio,Qt::SmoothTransformation));
    ui->graphicsView->setScene(scene);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void MainWindow::on_btnImages_clicked()
{
    QDir images = QFileDialog::getExistingDirectory(this,tr("Choose a Directory"),"C:"); //creates a file dialog to open folder

    clearLwImages();
    clearListImages();
    clearListImageFilePath();
    clearCreationDateList();

    foreach (QFileInfo var, images.entryInfoList()){ //for each loop to go through each file in the specified directory.
         ui->lwImages->addItem(var.baseName()); //populate list widget with file names
         listImages.append(var.baseName());
         listImageFilePath.append(var.absoluteFilePath());
    }           
}

void MainWindow::on_btnClasses_clicked()
{
    QDir classes = QFileDialog::getExistingDirectory(this,tr("Choose a Directory"),"C:");
    foreach (QFileInfo var, classes.entryInfoList()){
        ui->lwClasses->addItem(var.baseName());
        llClasses << var.baseName();
    }
}

//Clear Lists
void MainWindow::on_btnDeleteImage_clicked()
{
    clearLwImages();
    clearListImageFilePath();
    clearCreationDateList();
}
void MainWindow::clearCreationDateList(){
    creationDate.erase(creationDate.begin(), creationDate.end());
}
void MainWindow::clearListImageFilePath(){
    listImageFilePath.erase(listImageFilePath.begin(), listImageFilePath.end());
}
void MainWindow::clearLwImages(){
    ui->lwImages->clear();
}
void MainWindow::clearListImages(){
    listImages.erase(listImages.begin(), listImages.end());
}
void MainWindow::on_btnDeleteClass_clicked()
{
    ui->lwClasses->clear();
    llClasses.clear();
}

//SHPAES
void MainWindow::on_btnTriangle_clicked()
{
    QPolygonF Triangle;
    QPen redPen(Qt::red);
    redPen.setWidth(2);

    Triangle.append(QPointF(-50.,0));
    Triangle.append(QPointF(0,-50));
    Triangle.append(QPointF(50.,0));
    Triangle.append(QPointF(-50.,0));

    polygon = scene->addPolygon(Triangle,redPen);
    polygon->setFlag(QGraphicsItem::ItemIsMovable);

}
void MainWindow::on_btnSquare_clicked()
{
    QPen redPen(Qt::red);
    redPen.setWidth(2);
    rectangle = scene->addRect(-100,100,50,50,redPen);
    rectangle->setFlag(QGraphicsItem::ItemIsMovable);
}
void MainWindow::on_btnTrapezium_clicked()
{
    QPolygonF Trapezium;
    QPen redPen(Qt::red);
    redPen.setWidth(2);


    Trapezium.append(QPointF(10.,0));
    Trapezium.append(QPointF(50,0));
    Trapezium.append(QPointF(70,50));
    Trapezium.append(QPointF(-10,50));
    Trapezium.append(QPointF(10.,0));


    polygon = scene->addPolygon(Trapezium,redPen);
    polygon->setFlag(QGraphicsItem::ItemIsMovable);
}
void MainWindow::on_btnPoly_clicked()
{


}

//SAVE
void MainWindow::on_btnSave_clicked()
{

}

//DISPLAY IMAGE
void MainWindow::on_btnDispalyImg_clicked()
{

    //current code doesnt work so is commented out

    /*find the file path of the current item
    QString filePath = findPath();
    if (QString::compare(filePath,QString()) != 0){
        QImage image;
        bool valid = image.load(filePath);

    if(valid){
        displayImage(image);

    }else{
        //Displays message box with error info
        QMessageBox::warning(this,tr("File opening Error"), ("Unable to load image into project."));
        }
    }*/  
}
void MainWindow::displayImage(QImage image){
    //ui->tlImageView->clear();
    //image = image.scaledToWidth(ui->tlImageView->width(),Qt::SmoothTransformation);
    //ui->tlImageView->setPixmap(QPixmap::fromImage(image));
}

//SORT IMAGE NAMES
void MainWindow::on_btnSortNameASC_clicked()
{
    ui->lwImages->clear();

    int size;
    size = listImages.count();

    for(int i=0; i< size; i++)
        {
            for(int j=0; j< size-1; j++)
            {
                if(listImages[j]>listImages[j+1])
                {
                    QString tempImg = listImages[j];
                    QString tempImgFP = listImageFilePath[j];

                    listImages[j] = listImages[j+1];
                    listImages[j] = listImages[j+1];

                    listImages[j+1] = tempImg;
                    listImageFilePath[j+1]=tempImgFP;
                }
            }
        }
    ui->lwImages->addItems(listImages);
}

void MainWindow::on_btnSortNameDes_clicked()
{
   ui->lwImages->clear();

    int size;
    size = listImages.count();

    for(int i=0; i< size; i++)
        {
            for(int j=0; j< size-1; j++)
            {
                if(listImages[j]<listImages[j+1])
                {
                    QString tempImg = listImages[j];
                    QString tempImgFP = listImageFilePath[j];

                    listImages[j] = listImages[j+1];
                    listImageFilePath[j] = listImageFilePath[j+1];

                    listImages[j+1] = tempImg;
                    listImageFilePath[j+1]=tempImgFP;
                }
            }
        }
    ui->lwImages->addItems(listImages);

}

//SORT IMAGE DATES
void MainWindow::on_btnSortDateAcs_clicked()
{
    clearLwImages();
    clearCreationDateList();

    int size = listImages.count();

    for(int i=0; i< size; i++)
    {
        QFileInfo info(listImageFilePath[i]);
        creationDate.append(info.created().toString()+info.fileName()+"-"+info.baseName());

    }
    //Bubble Sort
    for(int i=0; i<size; i++)
    {
        for(int j=0; j<size-1; j++)
        {
            if(creationDate[j] > creationDate[j+1])
            {
                QString temp =creationDate[j];
                creationDate[j] = creationDate[j+1];
                creationDate[j+1] = temp;
            }
        }
    }
    ui->lwImages->addItems(creationDate);
}

void MainWindow::on_btnSortDateDes_clicked()
{
    clearLwImages();
    clearCreationDateList();

    int size = listImages.count();

    for(int i=0; i< size; i++)
    {
        QFileInfo info(listImageFilePath[i]);
        creationDate.append(info.created().toString()+"-"+info.baseName());
    }
    //Bubble Sort
    for(int i=0; i<size; i++)
    {
        for(int j=0; j<size-1; j++)
        {
            if(creationDate[j] < creationDate[j+1])
            {
                QString temp;
                temp = creationDate[j];
                creationDate[j] =creationDate[j+1];
                creationDate[j+1] = temp;
            }
        }
    }
    ui->lwImages->addItems(creationDate);

}

//SORT ClASSES
void MainWindow::on_btnSortClassAcs_clicked()
{
    ui->lwClasses->clear();

    int size = llClasses.count();

    QMutableLinkedListIterator<QString> i(llClasses);
    QStringList listClasses;

     i.toBack();
     while (i.hasPrevious()){
         QString val = i.previous();
         listClasses.append(val);
     }

     ui->lwClasses->addItems(listClasses);

}

void MainWindow::on_btnSortClassDec_clicked()
{

}
