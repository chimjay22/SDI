#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCore>
#include <QtGui>
#include <QDebug>
#include <QLinkedList>
#include <QListWidget>

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::MainWindow *ui;
    QGraphicsScene *scene;
    QGraphicsEllipseItem *ellipse;
    QGraphicsRectItem *rectangle;
    QGraphicsPolygonItem *polygon;


    QStringList listImages;
    QStringList indexImage;
    QStringList listImageFilePath;
    QStringList creationDate;
    QLinkedList<QString> llClasses;



private slots:

    void on_btnSortClassDec_clicked();
    void on_btnSortDateDes_clicked();
    void on_btnSortClassAcs_clicked();
    void on_btnSortNameASC_clicked();
    void on_btnSortDateAcs_clicked();
    void on_btnSortNameDes_clicked();

    void on_btnDispalyImg_clicked();
    void on_btnSave_clicked();

    void on_btnPoly_clicked();
    void on_btnTrapezium_clicked();
    void on_btnSquare_clicked();
    void on_btnTriangle_clicked();

    void on_btnDeleteClass_clicked();
    void on_btnDeleteImage_clicked();
    void on_btnClasses_clicked();
    void on_btnImages_clicked();
    void displayImage(QImage image);

    //Clear Lists
    void clearLwImages();
    void clearListImages();
    void clearListImageFilePath();
    void clearCreationDateList();

};

#endif // MAINWINDOW_H
