#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QPixmap>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void MainWindow::on_btnImages_clicked()
{

    QString fileName = QFileDialog::getOpenFileName(this, tr("Open File"),":images", tr("Images(*.png *.jpg *.jpeg *.bmp *.gif)"));

    if(QString::compare(fileName, QString()) !=0){

        QImage image;
        bool valid = image.load(fileName);

        if(valid){
            image=image.scaledToWidth(ui->tlImageView->width(), Qt::SmoothTransformation);
            ui->tlImageView->setPixmap(QPixmap::fromImage(image));
            ui->lwImages->addItem(fileName);

        }else{
            //Displays message box with error info
            QMessageBox::warning(this,tr("File opening Error"), ("Unable to load image into project."));
        }
    }

}

void MainWindow::on_btnClasses_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open File"),":classes", tr("Text(*.txt)"));

}

//DELETE FILES
void MainWindow::on_btnDeleteImage_clicked()
{

}

void MainWindow::on_btnDeleteClass_clicked()
{

}

//SHPAES

void MainWindow::on_btnTriangle_2_clicked()
{

}

void MainWindow::on_btnSquare_2_clicked()
{

}

void MainWindow::on_btnTrapezium_2_clicked()
{

}

void MainWindow::on_btnPoly_2_clicked()
{

}

//SAVE
void MainWindow::on_btnSave_clicked()
{

}
